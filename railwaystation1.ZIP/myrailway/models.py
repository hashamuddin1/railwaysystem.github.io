from django.db import models

# Create your models here.

class Customer(models.Model):
    firstname=models.CharField(max_length=40)
    lastname=models.CharField(max_length=40)
    mobilenumber=models.CharField(max_length=15)
    train=models.CharField(max_length=40)
    vaccine=models.CharField(max_length=40)
    customerid=models.CharField(max_length=20)
    cnicnumber=models.CharField(max_length=20)
    dateofjourney=models.DateField()
    numberofticket=models.IntegerField()
    customeraddress=models.CharField(max_length=40)
    paymentmethod=models.CharField(max_length=40)
    amountofpayment=models.IntegerField()
    customeremail=models.EmailField(max_length=40)



class Employee(models.Model):
    firstname=models.CharField(max_length=40)
    lastname=models.CharField(max_length=40)
    mobilenumber=models.CharField(max_length=15)
    vaccine=models.CharField(max_length=40)
    department=models.CharField(max_length=40)
    stationid=models.CharField(max_length=20)
    employeeid=models.CharField(max_length=20)
    salary=models.IntegerField()
    dateofjoining=models.DateField()
    employeeaddress=models.CharField(max_length=40)
    cnicnumber=models.CharField(max_length=40)
    dateofbirth=models.DateField()
    employeeemail=models.EmailField(max_length=40)

class Inventory(models.Model):
    inventoryname=models.CharField(max_length=40)
    inventoryid=models.CharField(max_length=40)
    stationid=models.CharField(max_length=15)
    productneeded=models.CharField(max_length=40)
    numberofmaterial=models.CharField(max_length=40)
    itemid=models.CharField(max_length=20)
    modifieddate=models.DateField()

class Newschedule(models.Model):
    trainname=models.CharField(max_length=40)
    trainid=models.CharField(max_length=40)
    route=models.CharField(max_length=45)
    seatbooked=models.IntegerField()
    dateofjourney=models.DateField()


class Payment(models.Model):
    paymentid=models.CharField(max_length=40)
    customerid=models.CharField(max_length=40)
    paymentdate=models.DateField()
    route=models.CharField(max_length=40)
    paymenttype=models.CharField(max_length=40)
    tax=models.IntegerField()
    receivingdate=models.DateField()

class Station(models.Model):
    stationname=models.CharField(max_length=40)
    stationid=models.CharField(max_length=40)
    location=models.CharField(max_length=40)
    city=models.CharField(max_length=40)
    railwaytrack=models.IntegerField()
    numberoftrain=models.IntegerField()
    managername=models.CharField(max_length=40)

class Ticket(models.Model):
    ticketid=models.CharField(max_length=40)
    trainid=models.CharField(max_length=40)
    issuedate=models.DateField()
    route=models.CharField(max_length=40)
    tickettype=models.CharField(max_length=40)

class Train(models.Model):
    trainname=models.CharField(max_length=40)
    trainid=models.CharField(max_length=40)
    shift=models.CharField(max_length=40)
    route=models.CharField(max_length=40)
    capacity=models.IntegerField()
    stationid=models.CharField(max_length=40)
    noofstation=models.IntegerField()
    fault=models.CharField(max_length=40)
    nextjourney=models.CharField(max_length=40)
    previousjourney=models.CharField(max_length=40)
  
    

 