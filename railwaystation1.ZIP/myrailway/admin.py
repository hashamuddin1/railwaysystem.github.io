from django.contrib import admin
from myrailway.models import Customer
from myrailway.models import Employee
from myrailway.models import Inventory
from myrailway.models import Newschedule
from myrailway.models import Payment
from myrailway.models import Station
from myrailway.models import Ticket
from myrailway.models import Train

# Register your models here.
admin.site.register(Customer)
admin.site.register(Employee)
admin.site.register(Inventory)
admin.site.register(Newschedule)
admin.site.register(Payment)
admin.site.register(Station)
admin.site.register(Ticket)
admin.site.register(Train)