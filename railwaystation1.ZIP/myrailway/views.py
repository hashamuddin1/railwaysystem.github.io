from django.shortcuts import render,HttpResponse
from django.db import connection
from datetime import datetime
from myrailway.models import Customer
from myrailway.models import Employee
from myrailway.models import Inventory
from myrailway.models import Newschedule
from myrailway.models import Payment
from myrailway.models import Station
from myrailway.models import Ticket
from myrailway.models import Train
from django.db.models import Count
from django.conf import settings
from django.core.mail import send_mail



def mail(request):
    subject = 'welcome to GFG world'
    message = f'Hi, thank you for registering in geeksforgeeks.'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = ["hashamlaptop@gmail.com", ]
    send_mail( subject, message, email_from, recipient_list )
    return render(request,"mail.html")



# Create your views here.
def index(request):
    return render(request,"index.html")
    #return HttpResponse("THIS IS MY HOMEPAGE")

def customer(request):
    if request.method=="POST":
        firstname=request.POST.get("f_name")
        lastname=request.POST.get("l_name")
        mobilenumber=request.POST.get("mobilenumber" )
        train=request.POST.get("train")
        vaccine=request.POST.get("vaccine")
        customerid=request.POST.get("customer_id")
        cnicnumber=request.POST.get("cnic_number")
        dateofjourney=request.POST.get("date_of_journey")
        numberofticket=request.POST.get("no_ticket")
        customeraddress=request.POST.get("address")
        paymentmethod=request.POST.get("payment")
        amountofpayment=request.POST.get("amount_of_payment")
        customeremail=request.POST.get("customeremail")
        customer=Customer(firstname=firstname,lastname=lastname,mobilenumber=mobilenumber,train=train,vaccine=vaccine,customerid=customerid,cnicnumber=cnicnumber,dateofjourney=dateofjourney,numberofticket=numberofticket,customeraddress=customeraddress,paymentmethod=paymentmethod,amountofpayment=amountofpayment,customeremail=customeremail)
        customer.save()
    return render(request,"customer.html")
    #return HttpResponse("THIS IS MY CUSTOMER PAGE")

def employee(request):
    if request.method=="POST":
        firstname=request.POST.get("empf_name")
        lastname=request.POST.get("empl_name")
        mobilenumber=request.POST.get("empnumber")
        vaccine=request.POST.get("empvaccine")
        department=request.POST.get("department")
        stationid=request.POST.get("empstationid")
        employeeid=request.POST.get("empid")
        salary=request.POST.get("salary")
        dateofjoining=request.POST.get("empjoiningdate")
        employeeaddress=request.POST.get("empaddress")
        cnicnumber=request.POST.get("empcnicnumber")
        dateofbirth=request.POST.get("empdateofbirth")
        employeeemail=request.POST.get("empemail")
        employee=Employee(firstname=firstname,lastname=lastname,mobilenumber=mobilenumber,vaccine=vaccine,department=department,stationid=stationid,employeeid=employeeid,salary=salary,dateofjoining=dateofjoining,employeeaddress=employeeaddress,cnicnumber=cnicnumber,dateofbirth=dateofbirth,employeeemail=employeeemail)
        employee.save()
    return render(request,"employee.html")
    #return HttpResponse("THIS IS MY EMPLOYEE PAGE")

def train(request):
    if request.method=="POST":
        trainname=request.POST.get("trainname")
        trainid=request.POST.get("trainid")
        shift=request.POST.get("shift")
        route=request.POST.get("trainroute")
        capacity=request.POST.get("traincapacity")
        stationid=request.POST.get("trastationid")
        noofstation=request.POST.get("tranostation")
        fault=request.POST.get("fault")
        nextjourney=request.POST.get("trainnextjourney")
        previousjourney=request.POST.get("traprejourney")
        train=Train(trainname=trainname,trainid=trainid,shift=shift,route=route,capacity=capacity,stationid=stationid,noofstation=noofstation,fault=fault,nextjourney=nextjourney,previousjourney=previousjourney)
        train.save()
    return render(request,"train.html")
    #return HttpResponse("THIS IS MY TRAIN PAGE")

def station(request):
    if request.method=="POST":
        stationname=request.POST.get("stationname")
        stationid=request.POST.get("station_id")
        location=request.POST.get("station_location")
        city=request.POST.get("stationcity")
        railwaytrack=request.POST.get("norailwaytrack")
        numberoftrain=request.POST.get("nooftrain")
        managername=request.POST.get("managername")
        station=Station(stationname=stationname,stationid=stationid,location=location,city=city,railwaytrack=railwaytrack,numberoftrain=numberoftrain,managername=managername)
        station.save()
    return render(request,"station.html")
    #return HttpResponse("THIS IS MY STATION PAGE")

def ticket(request):
    if request.method=="POST":
        ticketid=request.POST.get("ticketid")
        trainid=request.POST.get("tictrainid")
        issuedate=request.POST.get("ticketissuedate")
        route=request.POST.get("ticketroute")
        tickettype=request.POST.get("tickettype")
        ticket=Ticket(ticketid=ticketid,trainid=trainid,issuedate=issuedate,route=route,tickettype=tickettype)
        ticket.save()

    return render(request,"ticket.html")
    #return HttpResponse("THIS IS MY TICKET PAGE")

def payment(request):
    if request.method=="POST":
        paymentid=request.POST.get("payment_id")
        customerid=request.POST.get("paycustomer_id")
        paymentdate=request.POST.get("payment_date")
        route=request.POST.get("payroute")
        paymenttype=request.POST.get("paytype")
        tax=request.POST.get("tax")
        receivingdate=request.POST.get("receivingdate")
        payment=Payment(paymentid=paymentid,customerid=customerid,paymentdate=paymentdate,route=route,paymenttype=paymenttype,tax=tax,receivingdate=receivingdate)
        payment.save()
    return render(request,"payment.html")
    #return HttpResponse("THIS IS MY PAYMENT PAGE")

def inventory(request):
    if request.method=="POST":
        inventoryname=request.POST.get("inv_name")
        inventoryid=request.POST.get("inv_id")
        stationid=request.POST.get("station_id")
        productneeded=request.POST.get("productneeded")
        numberofmaterial=request.POST.get("numofmaterial")
        itemid=request.POST.get("itemid")
        modifieddate=request.POST.get("modified_date")
        inventory=Inventory(inventoryname=inventoryname,inventoryid=inventoryid,stationid=stationid,productneeded=productneeded,numberofmaterial=numberofmaterial,itemid=itemid,modifieddate=modifieddate)
        inventory.save()
    return render(request,"inventory.html")
    #return HttpResponse("THIS IS MY INVENTORY PAGE")

def newschedule(request):
    if request.method=="POST":
        trainname=request.POST.get("train_name")
        trainid=request.POST.get("train_id")
        route=request.POST.get("schroute")
        seatbooked=request.POST.get("seatbooked")
        dateofjourney=request.POST.get("schdateofjourney")
        newschedule=Newschedule(trainname=trainname,trainid=trainid,route=route,seatbooked=seatbooked,dateofjourney=dateofjourney)
        newschedule.save()
    return render(request,"newschedule.html")
    #return HttpResponse("THIS IS MY NEW SCHEDULE PAGE")


def employee_info(request):
    emp=Employee.objects.all()
    return render(request,"employee_info.html",{"emp":emp})

def inventory_info(request):
    inv=Inventory.objects.all()
    return render(request,"inventory_info.html",{"inv":inv})


def newschedule_info(request):
    newsch=Newschedule.objects.all()
    return render(request,"newschedule_info.html",{"newsch":newsch})

def payment_info(request):
    pay=Payment.objects.all()
    return render(request,"payment_info.html",{"pay":pay})

def station_info(request):
    stat=Station.objects.all()
    return render(request,"station_info.html",{"stat":stat})

def train_info(request):
    tra=Train.objects.all()
    return render(request,"train_info.html",{"tra":tra})

def ticket_info(request):
    tic=Ticket.objects.all()
    return render(request,"ticket_info.html",{"tic":tic})

def customer_vaccine(request):
    vac=Customer.objects.filter(vaccine="ASTRA ZENECA")
    return render(request,"customer_vaccine.html",{"vac":vac})


def vaccinated_employee(request):
    vac_emp=Employee.objects.exclude(vaccine="NOT VACCINATED")
    return render(request,"vaccinated_employee.html",{"vac_emp":vac_emp})


def salary_employee(request):
    sal_emp=Employee.objects.filter(salary__gt=30000)
    return render(request,"salary_employee.html",{"sal_emp":sal_emp})

def customer_group(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT count(*) as total_customer,train FROM pakistanrailway.myrailway_customer group by train''')
    row = cursor.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    # print(row)
    
     #   print(b[4])
    data = []
    for b in row:
         data_dic = {}
         data_dic['TOTAL_CUSTOMER'] = b[0]
         data_dic['TRAIN']= b[1]
         data.append(data_dic)
    #     #sum+=1
    #print(connection.queries)
    return render(request,"customer_group.html",{"data":data})

def customer_info(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM pakistanrailway.myrailway_customer''')
    row = cursor.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    # print(row)
    
     #   print(b[4])
    data = []
    for b in row:
         data_dic = {}
         data_dic['FIRST_NAME'] = b[1]
         data_dic['LAST_NAME']= b[2]
         data_dic['MOB_NO'] = b[3]
         data_dic['TRAIN']= b[4]
         data_dic['VACC'] = b[5]
         data_dic['C_ID']= b[6]
         data_dic['CNIC'] = b[7]
         data_dic['DATE']= b[8]
         data_dic['NO_TIC'] = b[9]
         data_dic['ADD']= b[10]
         data_dic['PAYMETHOD'] = b[11]
         data_dic['AMOUNT']= b[12]
         data_dic['EMAIL']= b[13]
         data.append(data_dic)
    #     #sum+=1
    #print(connection.queries)
    return render(request,"customer_info.html",{"data":data})

def product_sum(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT sum(numberofmaterial),productneeded FROM pakistanrailway.myrailway_inventory group by productneeded''')
    row = cursor.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TOTAL_PRODUCT'] = b[0]
          data_dic['PRODUCT_REQUIRED']= b[1]
          data.append(data_dic)
        #sum+=1
    print(connection.queries)
    return render(request,"product_sum.html",{"data":data})

 

def last_modified(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM pakistanrailway.myrailway_inventory where modifieddate= (SELECT MAX(date(modifieddate)) FROM pakistanrailway.myrailway_inventory ) ;''')
    row = cursor.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['INVENTORY_NAME'] = b[1]
          data_dic['INVENTORY_ID']= b[2]
          data_dic['STATION_ID'] = b[3]
          data_dic['PRODUCT_NEEDED']= b[4]
          data_dic['NO_OF_MATERIAL'] = b[5]
          data_dic['ITEM_ID']= b[6]
          data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
        #sum+=1
    print(connection.queries)
    return render(request,"last_modified.html",{"data":data})

def high_ticket(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule where seatbooked=(select max(seatbooked) from pakistanrailway.myrailway_newschedule);
 ;''')
    row = cursor.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TRAIN_NAME'] = b[1]
          data_dic['TRAIN_ID']= b[2]
          data_dic['ROUTE'] = b[3]
          data_dic['SEAT_BOOKED']= b[4]
          data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
        #sum+=1
    print(connection.queries)
    return render(request,"high_ticket.html",{"data":data})


def update_schedule(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule where seatbooked=(select max(seatbooked) from pakistanrailway.myrailway_newschedule)''')
    row = cursor.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TRAIN_NAME'] = b[1]
          data_dic['TRAIN_ID']= b[2]
          data_dic['ROUTE'] = b[3]
          data_dic['SEAT_BOOKED']= b[4]
          data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
        #sum+=1
    print(connection.queries)
    return render(request,"high_ticket.html",{"data":data})


def tuncate_customer(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''truncate pakistanrailway.myrailway_customer''')
    print(connection.queries)
    return HttpResponse("CUSTOMER RECORD IS DELETED")

def tuncate_employee(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''truncate pakistanrailway.myrailway_employee''')
    print(connection.queries)
    return HttpResponse("EMPLOYEE RECORD IS DELETED")

def tuncate_inventory(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''truncate pakistanrailway.myrailway_inventory''')
    print(connection.queries)
    return HttpResponse("INVENTORY RECORD IS DELETED")

def tuncate_newschedule(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''truncate pakistanrailway.myrailway_newschedule''')
    print(connection.queries)
    return HttpResponse("NEW SCHEDULE RECORD IS DELETED")

def pre_year(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''delete from pakistanrailway.myrailway_inventory where modifieddate<"2021-01-01"''')
    print(connection.queries)
    return HttpResponse("PREVIOUS RECORD IS DELETED")
    
def schedule_delay(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''UPDATE pakistanrailway.myrailway_newschedule SET dateofjourney = DATE_ADD(dateofjourney ,interval 7 day) where dateofjourney=current_date()''')
    cursor1=connection.cursor()
    cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    row = cursor1.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TRAIN_NAME'] = b[1]
          data_dic['TRAIN_ID']= b[2]
          data_dic['ROUTE'] = b[3]
          data_dic['SEAT_BOOKED']= b[4]
          data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"schedule_delay.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")

def sp_route(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor1=connection.cursor()
    cursor1.execute('''select * from pakistanrailway.myrailway_newschedule where route in ("KARACHI TO LAHORE","LAHORE TO PINDI","LAHORE TO KARACHI");''')
    row = cursor1.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TRAIN_NAME'] = b[1]
          data_dic['TRAIN_ID']= b[2]
          data_dic['ROUTE'] = b[3]
          data_dic['SEAT_BOOKED']= b[4]
          data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"sp_route.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")

def more_ticket(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    
    cursor1=connection.cursor()
    cursor1.execute('''select * from pakistanrailway.myrailway_newschedule group by dateofjourney having sum(seatbooked)>800;''')
    row = cursor1.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TRAIN_NAME'] = b[1]
          data_dic['TRAIN_ID']= b[2]
          data_dic['ROUTE'] = b[3]
          data_dic['SEAT_BOOKED']= b[4]
          data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"more_ticket.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")


def date_customer(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''select train,customerid,
case
when dateofjourney>current_date()  then "PENDING CUSTOMER"
when dateofjourney<current_date()  then "SECONDORY CUSTOMER"
END 
from pakistanrailway.myrailway_customer;''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    row = cursor.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['TRAIN'] = b[0]
          data_dic['CUSTOMER_ID']= b[1]
          data_dic['DATE'] = b[2]
        #   data_dic['SEAT_BOOKED']= b[4]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"date_customer.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")


def employee_station(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''select e.firstname,e.lastname,e.department,e.employeeid,s.stationname,s.stationid
from pakistanrailway.myrailway_employee as e
inner join pakistanrailway.myrailway_station as s
on e.stationid=s.stationid;''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    row = cursor.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['firstname'] = b[0]
          data_dic['lastname']= b[1]
          data_dic['dep'] = b[2]
          data_dic['eid'] = b[3]
          data_dic['stname']= b[4]
          data_dic['sid'] = b[5]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"employee_station.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")


def group_employee(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''select employeeid,department,
case
when salary>5000 and salary<=25000 then "INTERNSHIP EMPLOYEE"
when salary>25000 and salary<=35000  then "PERMANENT EMPLOYEE"
END 
from pakistanrailway.myrailway_employee;''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    row = cursor.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['eid'] = b[0]
          data_dic['dep']= b[1]
          data_dic['status'] = b[2]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"group_employee.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")



def customer_train(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''select c.firstname,c.lastname,c.customerid,t.trainname,t.trainid
from pakistanrailway.myrailway_customer as c
inner join pakistanrailway.myrailway_train as t
on c.train=t.trainname;''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    row = cursor.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['fname'] = b[0]
          data_dic['lname']= b[1]
          data_dic['cid'] = b[2]
          data_dic['tname']= b[3]
          data_dic['tid'] = b[4]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"customer_train.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")


def start_c(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''SELECT * FROM pakistanrailway.myrailway_inventory where itemid like "c%"''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    row = cursor.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['INVENTORY_NAME'] = b[1]
          data_dic['INVENTORY_ID']= b[2]
          data_dic['STATION_ID'] = b[3]
          data_dic['PRODUCT_NEEDED']= b[4]
          data_dic['NO_OF_MATERIAL'] = b[5]
          data_dic['ITEM_ID']= b[6]
          data_dic['MODIFIED_DATE']= b[7]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"start_c.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")

def pay_tran(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''START TRANSACTION;
SAVEPOINT d2;
delete from pakistanrailway.myrailway_payment where paymentdate=current_date();''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    cursor1=connection.cursor()
    cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_payment''')
    row = cursor1.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['PAYMENT_ID'] = b[1]
          data_dic['CUSTOMER_ID']= b[2]
          data_dic['PAYMENT_DATE'] = b[3]
          data_dic['ROUTE']= b[4]
          data_dic['PAYMENT_TYPE'] = b[5]
          data_dic['TAX']= b[6]
          data_dic['RECEIVING_DATE']= b[7]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"pay_tran.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")


def pay_roll(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''START TRANSACTION;
SAVEPOINT d2;
delete from pakistanrailway.myrailway_payment where paymentdate=current_date();
rollback to d2''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    cursor1=connection.cursor()
    cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_payment''')
    row = cursor1.fetchall()
    #print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['PAYMENT_ID'] = b[1]
          data_dic['CUSTOMER_ID']= b[2]
          data_dic['PAYMENT_DATE'] = b[3]
          data_dic['ROUTE']= b[4]
          data_dic['PAYMENT_TYPE'] = b[5]
          data_dic['TAX']= b[6]
          data_dic['RECEIVING_DATE']= b[7]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"pay_roll.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")


def sto_pro(request):
    #gro=Customer.objects.train.count("cnicnumber").group_by("train")
    cursor = connection.cursor()
    cursor.execute('''
    CREATE PROCEDURE demo6()
    BEGIN
    update pakistanrailway.myrailway_station set managername="hasham" where stationid="lah01";
    END;

    call demo6;''')
    # cursor1=connection.cursor()
    # cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_newschedule''')
    cursor1=connection.cursor()
    cursor1.execute('''SELECT * FROM pakistanrailway.myrailway_station ''')
    row = cursor1.fetchall()
    print(row)
    #return HttpResponse(row)
    #sum=0
    # row = Customer.objects.all().values('train').annotate(total=Count('train'))
    #print(row)
    
     #   print(b[4])
    data = []
    for b in row:
          data_dic = {}
          data_dic['STATION_NAME'] = b[1]
          data_dic['STATION_ID']= b[2]
          data_dic['LOCATION'] = b[3]
          data_dic['CITY']= b[4]
          data_dic['RAILWAY_TRACK'] = b[5]
          data_dic['NUMBER_OF_TRAIN']= b[6]
          data_dic['MANAGER_NAME']= b[7]
          #data_dic['STATUS']= b[3]
        #   data_dic['DATE_OF_JOURNEY'] = b[5]
        #   data_dic['ITEM_ID']= b[6]
        #   data_dic['MODIFIED_DATE']= b[7]
          data.append(data_dic)
    #     #sum+=1
    print(connection.queries)
    return render(request,"sto_pro.html",{"data":data})
    #return HttpResponse("TODAY'S SCHEDULE IS UPDATED")